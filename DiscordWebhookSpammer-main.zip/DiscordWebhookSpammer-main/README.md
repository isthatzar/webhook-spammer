# DiscordWebhookSpammer
Simple Python Webhook Spammer

Before you can use this you must run "pip install requests" in CMD. You can also run "pip install -r requirements.txt".
